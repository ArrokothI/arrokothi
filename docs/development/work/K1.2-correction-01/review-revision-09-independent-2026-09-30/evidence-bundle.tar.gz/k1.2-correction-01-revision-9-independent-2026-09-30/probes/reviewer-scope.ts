// Independent reachability probe; no production source changes.
import assert from 'node:assert/strict';
import { ExecutionCoordinator } from '../../src/index.ts';
import { accepted, caller, createRequest, recordingDriver, outcomeFor, submissionFor } from '../harness.ts';
const available = { definitionRevisions: ['weekly-report@3'], runtimeContractRevisions: ['runtime-contract@1'], progressCodecs: ['inline-json@1'] };
function fresh() {
 const driver = recordingDriver(); const kernel = new ExecutionCoordinator({driver}); const who = caller('fault','tenant-a');
 const {executionId} = accepted(kernel.createExecution(who,createRequest())); const open=accepted(kernel.dispatch(who,executionId,{bound:1}));
 return {driver,kernel,who,executionId,open};
}
let count=0;
for(const control of ['recoverExecution','reportProtocolFailure','requestTakeover'] as const) {
 for(const path of ['unknown','hidden','terminal','no-exchange','wrong-activation']) {
  if(control==='recoverExecution' && !['unknown','hidden'].includes(path)) continue;
  if(control==='requestTakeover' && path==='no-exchange') continue;
  const {driver,kernel,who,executionId,open}=fresh();
  if(path==='terminal'||path==='no-exchange') accepted(kernel.submitOutcome(who,outcomeFor(executionId,open,path==='terminal'?{next:{step:'complete',result:{done:true}}}:{}),submissionFor(driver,open.activationId)));
  const actor=path==='hidden'?caller('hidden','tenant-b'):who;
  const id=path==='unknown'?'missing-execution':executionId;
  const activationId=path==='wrong-activation'?'missing-activation':open.activationId;
  const request=control==='recoverExecution'?{activationId,available}:{activationId,writerEpoch:1,diagnostic:'x'};
  const result=kernel[control](actor,id,request as never);
  assert.equal(result.ok,false); if(result.ok) throw Error('unexpected');
  const expected=path==='unknown'||path==='hidden'?'unknown_destination':path==='terminal'?'terminal_destination':path==='no-exchange'?'no_unresolved_exchange':'stale_exchange';
  assert.equal(result.error.classification,expected);
  console.log(JSON.stringify({control,path,classification:result.error.classification,retainedRefusals:accepted(kernel.inspect(who,executionId)).refusals.length})); count++;
 }
}
for(const path of ['terminal','resolved','new-exchange','new-epoch','code-hold']) {
 const {driver,kernel,who,executionId,open}=fresh(); let entered=false;
 driver.isSafeToReplace=()=>{ if(entered)return true; entered=true;
  if(path==='new-epoch') accepted(kernel.requestTakeover(who,executionId,{activationId:open.activationId,writerEpoch:1}));
  else if(path==='code-hold') accepted(kernel.recoverExecution(who,executionId,{activationId:open.activationId,available:{...available,definitionRevisions:[]}}));
  else {
   accepted(kernel.submitOutcome(who,outcomeFor(executionId,open,path==='terminal'?{next:{step:'complete',result:{done:true}}}:{}),submissionFor(driver,open.activationId)));
   if(path==='new-exchange') {
    accepted(kernel.submitInput(who,{destination:executionId,requestKey:'new',kind:'update',payload:1}));
    accepted(kernel.dispatch(who,executionId,{bound:1}));
   }
  }
  return true;
 };
 const result=kernel.requestTakeover(who,executionId,{activationId:open.activationId,writerEpoch:1});
 assert.equal(result.ok,false); if(result.ok)throw Error('unexpected');
 const expected=path==='terminal'?'terminal_destination':path==='resolved'?'no_unresolved_exchange':path==='code-hold'?'recovery_held':'stale_exchange';
 assert.equal(result.error.classification,expected);
 console.log(JSON.stringify({control:'requestTakeover',path:'post-callback '+path,classification:result.error.classification,retainedRefusals:accepted(kernel.inspect(who,executionId)).refusals.length})); count++;
}
console.log(`REACHABLE CASES ABSENT FROM H FAULT SCENARIOS: ${count}`);
