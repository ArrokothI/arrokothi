# Reviewer probes and reproduction

These probes review candidate H `4a917f8caac04e7d9861e0ec3638662d52f9d3ae`. They do not implement a correction. Production source was unchanged throughout.

Extract the included candidate archive to a scratch directory and provide the repository's normal locked dependencies. The reviewer used existing local dependencies, Node v26.8.1, npm 11.19.0 and TypeScript 5.9.3 on Darwin arm64. No clean installation or Node-22 validation is claimed.

Copy the five `reviewer-*.ts` files into that export's `packages/kernel/tests/sweep/` directory. Run these commands from the export root:

```sh
node --experimental-strip-types --no-warnings packages/kernel/tests/sweep/reviewer-answer.ts --scenarios 'report: enter a protocol hold without' --summary
node --experimental-strip-types --no-warnings packages/kernel/tests/sweep/reviewer-refusal-grant.ts --scenarios 'takeover: refused by a Driver' --summary
node --experimental-strip-types --no-warnings packages/kernel/tests/sweep/reviewer-preapply.ts --scenarios 'outcome: continue' --summary
node --experimental-strip-types --no-warnings packages/kernel/tests/sweep/reviewer-delivery.ts --scenarios 'takeover: accepted' --summary
node --experimental-strip-types --no-warnings packages/kernel/tests/sweep/reviewer-scope.ts
```

The first four are copies of H's fault checker with altered **observations immediately before classification**. Their patches show every change, including logging. Their exit-0/PASS output is the defect: the checker accepts inconsistent observations. They are not production mutants, analyzer evasions or proof that clean H corrupts its own state. The pre-apply probe also expands stack logging and targets operation 12, establishing that the actual intercepted call is in value capture.

The fifth uses the original coordinator to demonstrate 16 reachable control cases absent from H's fault scenario list. It confirms classifications, not fault coherence on those paths.

The unmodified full suite and sweeps were separately executed. See the report for commands, results, inspected-only evidence and claim limits. `evidence/check-records-pinned.mjs` is a separate read-only adapter of the submitted record checker: Git queries use the available object database and substitute full H for HEAD; source-file reads use the scratch H export. Its local repository path must be adjusted on another machine.
