# Independent coverage map — K1.2-correction-01 revision 9

Reviewer: current Codex desktop session, GPT-6 (exact variant unexposed), 2026-09-30. Review-only. Full B/H snapshots and full binary B..H patch obtained. The report was initially opened to locate the candidate; its design opening was visible. This map derives obligations from the governing baseline, canonical owners, contract and owner amendments before substantive report/evidence reconciliation. Later branch work is not the candidate.

B a20d278185eaffc7f8b7489345a3624231ff6e6d; C 81dca4575ea56cfdde5b5f8ed72c439c7ec31821; H 4a917f8caac04e7d9861e0ec3638662d52f9d3ae.

| Obligation | Independent distinguishing examination | Whole result / forbidden mutations |
|---|---|---|
| C1 scope and powers | Hidden vs absent, visible without control, foreign grant; observation counting at all four entries | No disclosure or content observation before scope; hidden records unchanged; control distinct from inspect and attempt submission |
| C2 replay + C3 identity | Minted maximum-key/long-namespace/surrogate IDs, later exchanges, terminal, conflicting content; independently malformed each coordinate | Exact receipt replay without grant; conflict before fresh validation; no lossy diagnostic affects lookup; missing coordinates cannot falsely establish staleness |
| C3 + C13 capture | At/over four limits, multiple large roots, hostile own fields/Proxy, ambient residue, reentry | One coherent captured value; eager roots; no pre-authority diagnostic leak; one refusal only; no accepted mutation/retry |
| C4/C5/C6 | Continue then dispatch, terminal completion/failure with off-batch Events, both orders of input and acceptance | Entire pinned batch acknowledged; other Events queued or terminal-disposed; exact progress/output/receipt/revision; no terminal reopening |
| C7 | Effect-bearing next steps; inaccessible wait payload | Whole refusal, no action evidence, no wait read |
| C8/C9/C10 | Redelivery vs takeover vs new exchange; all control return paths; safe callback reentry; both holds and both clears | ID/input retained, epochs/grants correct; only one decision; holds/history/answers causal and immutable; Driver invoked only after complete commit |
| C11/C12 | Saved late settlements after newer attempts/resolution; replay and retained grants; next input/refusal after failed controls | Only owned delivery row settles; whole view and both next positions exactly match an allowed decision; saved grant power correct |
| DEC-4/5/6/7 diagnostics | Long matching and mismatching identity; >8 heterogeneous issues over roots; type-only labels; explicit protocol diagnostic | Bounded details and exact first-occurrence weighted suffix; exact structured coordinates; protocol diagnostic keeps its separate 1024-unit rule; V-D1 is transferred |
| DEC-8 runtime evidence | Enumerate poisoned names/prototypes, frame attribution, module hooks, scenario paths and comparison oracle; challenge plausible optional read on reachable path | No zone firing; actual result and state match control; classify disclosed blind spots separately, no arbitrary analyzer-soundness demand |
| DEC-9 runtime evidence | Enumerate control exits and intercepted operations; inspect all result branches and tolerated exceptions; feed altered observations to the checker | Whole returned decision, whole view, next acceptance/refusal and saved grant checked; precommit fault = no-call; allowed contained refusal or commit must be complete and causally justified |
| C14 | Source/export/dependency inventory vs measured files; removed assertions and package scripts | Private zone; no legacy import or portable-leaf claim |
| C15 and process | All Layer-3 changes vs B, decision provenance, markers, examples and migration claims; C..H allowlist and evidence manifest; every prior finding | Single owner; no status in specification, silent choice, generalized token or durability claim; exact candidate and honest evidence limits |

Methods: normative decisions, deterministic execution, in-process race/fault, process/documentation. Native fidelity R1, E1 K1.4, persistence K3, packaging S1 and V-D1/K1.1-correction-03 are excluded explicitly. No external gate or durability proof will be inferred from mechanical tests. Review will continue after findings.
